import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import os
from dotenv import load_dotenv

# Configuració de la pàgina
st.set_page_config(page_title="Classificador d'imatges médiques", layout="wide")
st.title("Anàlisi per a detecció de cancer de pell")

# Cargar variables de entorno
load_dotenv()
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "http://n8n:5678/webhook/predict-image")

# Funció para mostrar resultados con colores
def mostrar_resultat(etiqueta, probabilitat):
    if etiqueta == "benigne":
        st.success(f"### Resultat: **{etiqueta.capitalize()}** (Probabilitat: {probabilitat:.2%})")
    else:
        st.error(f"### Resultat: **{etiqueta.capitalize()}** (Probabilitat: {probabilitat:.2%})")

# Subida de archivo
img_file = st.file_uploader("Puja una imatge per a predicció", type=["jpg", "jpeg", "png"])

if img_file:
    # Muestra la imagen con tamaño más pequeño (ej: 250px de ancho)
    st.image(img_file, caption="Imatge per analitzar", width=250)
    
    if st.button("Predicció imatge i enviament de correu."):
        with st.spinner("Processant..."):
            try:
                # Enviar al servidor
                files = {"file": (img_file.name, img_file, img_file.type)}
                response = requests.post(WEBHOOK_URL, files=files)
                response.raise_for_status()
                
                result = response.json()
                labels = ["benigne", "maligne"]
                classe_predita = labels[result["class_index"]]
                probabilitat = result["probabilities"][result["class_index"]]
                
                # Mostrar resultado principal con colores
                st.markdown("---")
                mostrar_resultat(classe_predita, probabilitat)
                st.markdown("---")
                
                # Gràfic de tarta (pie chart) con sector resaltado
                df = pd.DataFrame({
                    "Classe": labels,
                    "Probabilitat": result["probabilities"]
                })
                
                # Hacemos que el sector de la clase predicha sobresalga
                pull = [0.08 if i == result["class_index"] else 0 for i in range(len(labels))]
                
                fig = px.pie(
                    df,
                    names="Classe",
                    values="Probabilitat",
                    title="Distribució de probabilitats",
                    hole=0.4,
                    color="Classe",
                    color_discrete_map={"benigne": "#2ecc71", "maligne": "#e74c3c"}
                )
                fig.update_traces(
                    textinfo='percent+label',
                    textfont_size=14,
                    marker=dict(line=dict(color='#FFFFFF', width=2)),
                    pull=pull
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Tabla detallada
                st.subheader("Probabilitats detallades")
                col1, col2 = st.columns(2)
                with col1:
                    st.metric(label="Benigne", value=f"{result['probabilities'][0]:.2%}",
                             delta_color="off")
                with col2:
                    st.metric(label="Maligne", value=f"{result['probabilities'][1]:.2%}",
                             delta_color="off")
              
            except requests.exceptions.RequestException as e:
                st.error("Error en la connexión amb el servidor de predicció")
                st.error(f"Detalls: {str(e)}")
            except ValueError as e:
                st.error("Error en processar la resposta del servidor")
                st.error(f"Detalls: {str(e)}")
            except Exception as e:
                st.error("Error inesperat")
                st.error(f"Detalls: {str(e)}")